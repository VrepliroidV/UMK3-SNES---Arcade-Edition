UMK3 ARCADE EDITION (beta 63)
by Repliroid do Futuro
=============================

A Super Nintendo hack of Ultimate Mortal Kombat 3 that brings the game
closer to the arcade version. It includes everything from Lucas Dext5r's
UMK3 Deluxe (MK3 stages, Sheeva, Chameleon, stage fatalities) and uses
Nemesis_C's Genesis "UMK3 Arcade" hack as a reference.

(Full changelog in Portuguese: LEIA-ME.txt)


HOW TO APPLY
------------
Patch: UMK3_arcade_edition.ips

Apply to: Ultimate Mortal Kombat 3 (USA).sfc
  size: 4,194,304 bytes (4 MB, no header)
  original ROM MD5:  0644da71f79d405a22934daa1474cefc
  patched ROM MD5:   c31f8e8fc6c4cdb932874fe89e0a02d3

- The patched ROM is 8 MB (64 Mbit, ExHiROM): the new content does not
  fit in the original 4 MB. Use a patcher that can expand the file
  (Floating IPS, Lunar IPS, ROM Patcher JS, UniPatcher).
- If your ROM is 4,194,816 bytes (512-byte header, common in .smc
  files), remove the header first (ROM Patcher JS can do it).
- No MSU-1 needed. Tested in Snes9x. Runs on emulators and flashcarts
  that support 64 Mbit ExHiROM (e.g. FXPak / SD2SNES). Flashcarts
  limited to 32 Mbit will not run it.


LATEST CHANGES (betas 57-63)
----------------------------
- Ermac's fatality 2 (head punch: Run, Block, Run, Run, HK, close) can
  now be performed. On the original SNES cart a stray byte in Ermac's
  move list made the game read that entry one byte off. (beta 63)
- Motaro and Shao Kahn picked by a player can now fight on any stage
  (the normal order or the KOMBAT ZONE pick). CPU bosses in the tower
  still fight on their own stages. (beta 62)
- Playable Motaro: landing from a jump has a sound again (the same thud
  the CPU Motaro uses). (beta 61)
- Fixed a crash on Liu Kang's fatality (Fwd, Fwd, Down, Down, LK): a
  Chameleon table entry was written 2 bytes too far, over the start of
  that fatality's code. (beta 60)
- Fixed the graphics glitch in fights with Motaro and/or Shao Kahn (e.g.
  Motaro vs Shao Kahn): pink dots on the floor and background, wrong
  colors on the fighters. In the heaviest frames the end-of-frame work ran
  out of time, and the scanline effects were turned on without being
  reset, writing random colors into the palettes. They are now reset
  when that happens, and the sprite graphics sent per frame in a fight
  are capped a bit lower so it almost never happens. (beta 59)
- Bell Tower: fixed occasional frames where the whole screen was garbled
  (e.g. Chameleon vs Jax doing combos): the rope drawing code is about
  4x faster now. (beta 59)
- Liu Kang: after his launcher combo (HP, HP, Back+LP), every later hit
  did only 1/4 of the damage until the end of the round. Fixed. (beta 58)
- The Bridge: the gap under the floor is filled like on the other stages.
  Jump-in HP + combo now connects on Kitana, Jade and Mileena like on
  everyone else. (beta 57)


HIGHLIGHTS
----------
- Arcade-style select screen (7/7/5/5/5, "SELECT YOUR FIGHTER") with
  everyone unlocked: Sheeva, Chameleon, Human Smoke, Motaro and Shao
  Kahn, each with a slot and portrait. "?" slot = random select.
- Chameleon: cycles through every ninja's colors, one special move from
  each ninja, his own name, announcer voice, brutality and green blood.
- Motaro and Shao Kahn: big VS-screen art and biographies; Motaro can't
  be launched or juggled.
- Arcade intro story (11 screens), redesigned main menu and mode select,
  CHOOSE YOUR DESTINY tower with the GOD tower.
- Fighter names inside the life bars, as in the arcade.
- Air combos for Kitana, Jade and Mileena.
- KOMBAT ZONE stage select (L / R on the select screen, cheat menu).
- OPTIONS > CREDITS screen.
- Many sound, announcer and graphics fixes; less slowdown in the Shao
  Kahn and Motaro fights.


TRAINING MODE
-------------
On the mode select screen press Down to reach TRAINING.
- Everything is done with controller 1: pick your fighter, then pick
  the opponent.
- KOMBAT ZONE is on: L / R choose the stage before you pick.
- The opponent stands still; health never runs out; the clock stops.
- START + SELECT together leave training and return to the mode screen.


CREDITS
-------
UMK3 Deluxe content is used with permission from its author, Lucas
Dext5r.

- UMK3 Deluxe: Lucas Dext5r (2022)
- Original MSU-1 patch: Kurrono, Relikk, Conn
- Genesis "UMK3 Arcade" hack (reference): Nemesis_C
- This patch: Repliroid do Futuro (Gabriel Calmon)
