UMK3 ARCADE EDITION (beta 73)
by Repliroid do Futuro
=============================

A Super Nintendo hack of Ultimate Mortal Kombat 3 that brings the game
closer to the arcade version. It includes everything from Lucas Dext5r's
UMK3 Deluxe (MK3 stages, Sheeva, Chameleon, stage fatalities) and uses
Nemesis_C's Genesis "UMK3 Arcade" hack as a reference.

(Full changelog in Portuguese: LEIA-ME.txt)


HOW TO APPLY
------------
Patch: UMK3_arcade_edition.ips

Apply to: Ultimate Mortal Kombat 3 (USA).sfc
  size: 4,194,304 bytes (4 MB, no header)
  original ROM MD5:  0644da71f79d405a22934daa1474cefc
  patched ROM MD5:   ff3e4d3431b8e287cf43edc54ebfaf5a

- The patched ROM is 8 MB (64 Mbit, ExHiROM): the new content does not
  fit in the original 4 MB. Use a patcher that can expand the file
  (Floating IPS, Lunar IPS, ROM Patcher JS, UniPatcher).
- If your ROM is 4,194,816 bytes (512-byte header, common in .smc
  files), remove the header first (ROM Patcher JS can do it).
- No MSU-1 needed. Tested in Snes9x and bsnes. Runs on emulators and
  flashcarts that support 64 Mbit ExHiROM (e.g. FXPak / SD2SNES).
  Flashcarts limited to 32 Mbit will not run it.


LATEST CHANGES (betas 57-73)
----------------------------
- Triborg's juggle: after the jump kick the opponent now falls away on
  the diagonal (it used to go up again). The fall is a bit slower, so
  the teleport still catches it in the air. (beta 73)
- Shao Kahn's Lost Treasures: fixed the fatality demonstrations. The
  Deluxe had changed 5 of the game's 8 demo lists into pairs where both
  fighters did a finisher at once (friendship + babality, two
  fatalities, animalities), which broke the scenes. They are back to the
  original lists: one fighter does his fatality, the other stands.
  Treasure 9 shows everything (fatalities 1 and 2, then friendships and
  babalities two at a time, as in the original game). (beta 73)
- Nightwolf's friendship: the MK2 arcade cabinet that falls next to him
  no longer flashes through the ninja colors (Chameleon's color cycle
  was catching its palette). (beta 73)
- Shao Kahn's Lost Treasures: after you beat Shao Kahn in 1 player, the
  treasure screen comes up, as in the arcade (the SNES game only had it
  in the 8-player tournament), with the menu music. Treasure 0 goes on
  to your ending; treasures 6 and 7 are the original Endurance fights
  (Noob Saibot + Ermac, Classic Sub-Zero + Human Smoke) on normal
  stages; treasure 8 is a fight against TRIBORG. (beta 72)
- New hidden fighter: TRIBORG, the three cyborgs in one (Cyrax, Sektor
  and Smoke), with their colors cycling. Beat him in treasure 8 to
  unlock him (a "YOU UNLOCKED TRIBORG" screen shows up), then press
  SELECT on the "?" slot of the select screen. The game has no save: he
  stays unlocked until you turn it off or reset. (beta 72)
    Cyrax's net: Back, Back + LK
    Cyrax's bombs: hold LK, Fwd, Fwd + HK (far) / Back, Back + HK (close)
    Sektor's missile: Fwd, Fwd + LP
    Sektor's homing missile: Fwd, Down, Back + HP
    Smoke's spear: Back, Back + LP
    Smoke's teleport punch: Fwd, Fwd + LK (also in the air)
    Smoke's air throw (Block in the air) and invisibility (Up, Up + Run)
    Combos: HP, HP, Down + LP (launcher) / HP, HP, HK, HK /
      HP, HP, LK, HK, LP
    Juggle: after HP, HP, Down + LP, jump in with a kick, teleport in
      the air (it knocks the opponent up again), land and throw the
      spear or the net, do the combo again, then only normal hits and
      the air throw work until the opponent lands
    Fatalities: Cyrax Down, Down, Up, Down + HP; Sektor Fwd, Fwd, Fwd,
      Back + Block (far); Smoke Up, Up, Fwd, Down (hold Block, far)
    Smoke's brutality: Y, A, A, X, L, L, B, B, Y, L, L (HP, LK, LK, HK,
      BL, BL, LP, LP, HP, BL, BL)
  He has his own select and tower portraits, VS art, life bar name,
  "TRIBORG WINS", announcer voice, Smoke's victory pose, biography
  ("???" until he is unlocked) and ending, and no smoke cloud around
  him. He also works in the team modes. (beta 72)
- Player Motaro: new tail fireball (it comes out of the tip of his tail)
  with Down, Back + LK, and the screen shakes when he lands from a jump.
  (beta 72)
- Motaro's grab (CPU and player) no longer does damage when it catches;
  only the punch hurts, also when the opponent is blocking. (beta 72)
- Noob Saibot's teleport throw on Sheeva: she no longer ends up far from
  him in Sonya's pose; she is held like everyone else. (beta 72)
- Khameleon: after a Mercy the announcer no longer says "Jade". (beta 72)
- The game's version is shown on the OPTIONS screen, small, in the
  bottom right corner on the CREDITS line (VER.BETA71). (beta 71)
- Tower and 2-player stages are now picked at random from all 17 (each
  one once before any repeats, never the same twice in a row). The
  tower used to go through the same order every time, MK3 stages
  first, and the first fight after power-on was always on the Rooftop.
  The CPU Motaro and Shao Kahn keep their own stages, and KOMBAT ZONE
  still picks the stage. (beta 71)
- Endurance fights have random opponents (no repeats, never your own
  fighter). They used to be the same pairs (Kitana then Sheeva, Jax
  then Nightwolf). (beta 71)
- Fixed a tower freeze: sometimes a stage (e.g. Jade's Desert) showed
  up with no fighters, only the music. Some of the hack's variables
  were in the memory the game uses for its processes, and with many of
  them at once (Sheeva, Scorpion's Lair, Hidden Portal) the game got
  lost. (beta 71)
- The Pit 3: during the stage fatality, as the camera goes down, the
  names and life bars no longer vanish or break. (beta 71)
- Motaro fights (worse with Chameleon): fixed the short picture
  glitches (HUD and floor drawn a few lines off for one frame). In the
  heaviest frames the end-of-frame work ran out of time; the scanline
  effects (HUD, floor) now always start in place. (beta 71)
- Air throws on Liu Kang (Human Smoke, Scorpion): he no longer pops up
  behind the attacker when he lands. (beta 71)
- Khameleon's brutality now uses Mileena's commands: Y, B, B, Y, L, X,
  A, X, L, Y, B (HP, LP, LP, HP, BL, HK, LK, HK, BL, HP, LP). Jade keeps
  hers. (beta 71)
- When Shao Kahn wins a round the announcer says "I Win". The clip was
  already there, but it was asked for right away and the blood dripping
  on the floor took its voice; it now waits for the loser's scream to
  end. (beta 71)
- Removed every leftover of the Deluxe's animality (the game has no
  animality commands): the CPU's path to it, its table, its sounds and
  the "Animality" call. More free space in the ROM. (beta 71)
- CPU Motaro: his grab no longer pulls the opponent in from far away at
  once; he reaches out first (time to get away), only catches someone
  in reach and on the ground, and does not try from too far. Grabbed by
  the player's Motaro, he no longer hangs in the air after the punch. At
  the end of a combo he rears back and slides away much further, then
  waits a moment before attacking. (beta 70)
- Motaro (CPU and player) takes the heavy hit sound on the punch of the
  grab, on uppercuts and on the last hit of a combo. (beta 70)
- Fixed: pressing HP over and over made Khameleon throw Mileena's sai
  by accident. The sai now comes out only the proper way (hold HP, let
  go); mashing HP gives the punches and the combo. (beta 69)
- Khameleon has her own ending (one screen, her story over Jade's
  picture with Khameleon's colors cycling); it used to be Jade's.
  (beta 68)
- The CPU Khameleon now uses her own moves: Kitana's fan, Mileena's sai
  and Jade's boomerangs, picked at random (the game's AI picked her
  moves as Jade's). (beta 67)
- CHOOSE YOUR DESTINY: the 4th tower shows GOD again (beta 66 showed
  "KHAMELEON W..." there). (beta 67)
- New fighter: KHAMELEON (the Nintendo 64 Mortal Kombat Trilogy ninja),
  in Human Smoke's old slot. She cycles through Kitana's, Jade's and
  Mileena's colors and uses moves from all three (beta 66):
    Kitana's fan: Fwd, Fwd + HP + LP
    Jade's boomerangs: Back, Fwd + HP (high) / LP (straight) / LK (low);
      Back, Back, Fwd + LP (returning)
    Mileena's sai: hold HP, let go
    Combo: HP, HP, LP, LP, HK, HK, Down, Fwd + LK (7 hits, launcher)
    Mileena's throw
    Fatalities (close): Kitana's kiss (Run, Run, Block, Block + LK),
      Mileena's man-eater (Down, Fwd, Down, Fwd + LP), Jade's staff
      (Up, Up, Down, Fwd + HP)
    Stage fatality: Down, Down, Down + LP (close)
    Jade's friendship (Back, Down, Back, Back + HK) and babality
      (Down, Down, Fwd, Down + HK)
  She has her own select and tower portraits, VS art, life bar name,
  "KHAMELEON WINS", announcer voice and biography, and works in the
  tower, team modes and tournament.
- Human Smoke is now on Smoke's slot: press SELECT on Smoke to swap the
  portrait (with a fade) to Human Smoke and back. Random select never
  picks Human Smoke. (beta 66)
- The X button on the select screen picks the fighter's color (each
  fighter has two outfits; the second one used to show up only on P2 in
  a mirror match). In a mirror match with the same color, P2 (or the
  CPU) gets the other one. X no longer picks the fighter. Not for
  Chameleon and Khameleon (they cycle colors) or one-color fighters.
  Ermac and Noob got their second color back (darker red Ermac,
  all-black Noob, as in UMK3). (beta 66)
- Hidden Portal: no fighters running across the bridge and no Shao Kahn
  laugh before the fight. (beta 66)
- Stage fatalities: Chameleon's is now Fwd, Down + HP (Y), close.
  Mileena's (Down, Down, Down + LP) had to be done in 0.4 s, now 0.7 s.
  Soul Chamber no longer has one (the opponent got up again); they are on
  Scorpion's Lair, Bell Tower, The Pit 3 and The Subway. The Subway
  train passes 3x faster. (beta 66)
- Fixed the life bar glitch seen on some emulators and flash carts (a
  colored block over a letter of the name, a broken run meter): the HUD
  no longer changes a palette color mid-screen. (beta 65)
- BIOGRAPHIES is now an item of the SECRET STUFF screen, under SOUND
  TEST, in the big font (it was inside KOOLER STUFF). (beta 64)
- Ermac's fatality 2 (head punch: Run, Block, Run, Run, HK, close) can
  now be performed. On the original SNES cart a stray byte in Ermac's
  move list made the game read that entry one byte off. (beta 63)
- Motaro and Shao Kahn picked by a player can now fight on any stage
  (the normal order or the KOMBAT ZONE pick). CPU bosses in the tower
  still fight on their own stages. (beta 62)
- Playable Motaro: landing from a jump has a sound again (the same thud
  the CPU Motaro uses). (beta 61)
- Fixed a crash on Liu Kang's fatality (Fwd, Fwd, Down, Down, LK): a
  Chameleon table entry was written 2 bytes too far, over the start of
  that fatality's code. (beta 60)
- Fixed the graphics glitch in fights with Motaro and/or Shao Kahn (e.g.
  Motaro vs Shao Kahn): pink dots on the floor and background, wrong
  colors on the fighters. In the heaviest frames the end-of-frame work ran
  out of time, and the scanline effects were turned on without being
  reset, writing random colors into the palettes. They are now reset
  when that happens, and the sprite graphics sent per frame in a fight
  are capped a bit lower so it almost never happens. (beta 59)
- Bell Tower: fixed occasional frames where the whole screen was garbled
  (e.g. Chameleon vs Jax doing combos): the rope drawing code is about
  4x faster now. (beta 59)
- Liu Kang: after his launcher combo (HP, HP, Back+LP), every later hit
  did only 1/4 of the damage until the end of the round. Fixed. (beta 58)
- The Bridge: the gap under the floor is filled like on the other stages.
  Jump-in HP + combo now connects on Kitana, Jade and Mileena like on
  everyone else. (beta 57)


HIGHLIGHTS
----------
- Arcade-style select screen (7/7/5/5/5, "SELECT YOUR FIGHTER") with
  everyone unlocked: Sheeva, Chameleon, Khameleon, Motaro and Shao
  Kahn, each with a slot and portrait (Human Smoke on Smoke's slot).
  "?" slot = random select.
- Chameleon: cycles through every ninja's colors, one special move from
  each ninja, his own name, announcer voice, brutality and green blood.
- Khameleon: cycles through Kitana's, Jade's and Mileena's colors, with
  moves, combo and one fatality from each of them.
- Triborg (hidden): Cyrax, Sektor and Smoke in one, with moves, combos,
  a juggle and one fatality from each of them. Unlock him by beating him
  in Shao Kahn's Lost Treasures.
- Shao Kahn's Lost Treasures after beating Shao Kahn in 1 player.
- X on the select screen picks the fighter's color; SELECT on Smoke
  swaps to Human Smoke.
- Motaro and Shao Kahn: big VS-screen art and biographies; Motaro can't
  be launched or juggled.
- Arcade intro story (11 screens), redesigned main menu and mode select,
  CHOOSE YOUR DESTINY tower with the GOD tower.
- Fighter names inside the life bars, as in the arcade.
- Air combos for Kitana, Jade and Mileena.
- Random stage order in the tower and 2-player fights; random Endurance
  opponents.
- KOMBAT ZONE stage select (L / R on the select screen, cheat menu).
- OPTIONS > CREDITS screen.
- Many sound, announcer and graphics fixes; less slowdown in the Shao
  Kahn and Motaro fights.


TRAINING MODE
-------------
On the mode select screen press Down to reach TRAINING.
- Everything is done with controller 1: pick your fighter, then pick
  the opponent.
- KOMBAT ZONE is on: L / R choose the stage before you pick.
- The opponent stands still; health never runs out; the clock stops.
- START + SELECT together leave training and return to the mode screen.


CREDITS
-------
UMK3 Deluxe content is used with permission from its author, Lucas
Dext5r.

- UMK3 Deluxe: Lucas Dext5r (2022)
- Original MSU-1 patch: Kurrono, Relikk, Conn
- Genesis "UMK3 Arcade" hack (reference): Nemesis_C
- This patch: Repliroid do Futuro (Gabriel Calmon)
