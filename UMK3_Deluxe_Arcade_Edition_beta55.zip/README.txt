UMK3 DELUXE - ARCADE EDITION (beta 55)
by Repliroid do Futuro
======================================

A Super Nintendo hack of Ultimate Mortal Kombat 3 that brings the game
closer to the arcade version. It includes everything from Lucas Dext5r's
UMK3 Deluxe (MK3 stages, Sheeva, Chameleon, stage fatalities) and uses
Nemesis_C's Genesis "UMK3 Arcade" hack as a reference.

(Full changelog in Portuguese: LEIA-ME.txt)


HOW TO APPLY
------------
Patch: umk3_deluxe_arcade_beta55.ips

Apply to: Ultimate Mortal Kombat 3 (USA).sfc
  size: 4,194,304 bytes (4 MB, no header)
  original ROM MD5:  0644da71f79d405a22934daa1474cefc
  patched ROM MD5:   8ffe2846601932bba9d4179decca5cea

- The patched ROM is 8 MB (64 Mbit, ExHiROM): the new content does not
  fit in the original 4 MB. Use a patcher that can expand the file
  (Floating IPS, Lunar IPS, ROM Patcher JS, UniPatcher).
- If your ROM is 4,194,816 bytes (512-byte header, common in .smc
  files), remove the header first (ROM Patcher JS can do it).
- No MSU-1 needed. Tested in Snes9x. Runs on emulators and flashcarts
  that support 64 Mbit ExHiROM (e.g. FXPak / SD2SNES). Flashcarts
  limited to 32 Mbit will not run it.


HIGHLIGHTS
----------
- Arcade-style select screen (7/7/5/5/5, "SELECT YOUR FIGHTER") with
  everyone unlocked: Sheeva, Chameleon, Human Smoke, Motaro and Shao
  Kahn, each with a slot and portrait. "?" slot = random select.
- Chameleon: cycles through every ninja's colors, one special move from
  each ninja, his own name, announcer voice, brutality and green blood.
- Motaro and Shao Kahn: big VS-screen art and biographies; Motaro can't
  be launched or juggled.
- Arcade intro story (11 screens), redesigned main menu and mode select,
  CHOOSE YOUR DESTINY tower with the GOD tower.
- Fighter names inside the life bars, as in the arcade.
- Air combos for Kitana, Jade and Mileena.
- KOMBAT ZONE stage select (L / R on the select screen, cheat menu).
- OPTIONS > CREDITS screen.
- Many sound, announcer and graphics fixes; less slowdown in the Shao
  Kahn and Motaro fights.


TRAINING MODE
-------------
On the mode select screen press Down to reach TRAINING.
- Everything is done with controller 1: pick your fighter, then pick
  the opponent.
- KOMBAT ZONE is on: L / R choose the stage before you pick.
- The opponent stands still; health never runs out; the clock stops.
- START + SELECT together leave training and return to the mode screen.


CREDITS
-------
Lucas Dext5r announced on his YouTube channel that he would no longer
work on UMK3 Deluxe and that anyone was free to continue it. This patch
is a continuation of his work.

- UMK3 Deluxe: Lucas Dext5r (2022)
- Original MSU-1 patch: Kurrono, Relikk, Conn
- Genesis "UMK3 Arcade" hack (reference): Nemesis_C
- This patch: Repliroid do Futuro (Gabriel Calmon)
