UMK3 - EXTENDED EDITION (beta 99)
by Repliroid do Futuro
=================================

A Super Nintendo hack of Ultimate Mortal Kombat 3 that brings the game
closer to the arcade version. It includes everything from Lucas Dext5r's
UMK3 Deluxe (MK3 stages, Sheeva, Chameleon, stage fatalities) and uses
Nemesis_C's Genesis "UMK3 Arcade" hack as a reference.

(Full changelog in Portuguese: LEIA-ME.txt)


HOW TO APPLY
------------
Patch: UMK3_extended_edition.ips

Apply to: Ultimate Mortal Kombat 3 (USA).sfc
  size: 4,194,304 bytes (4 MB, no header)
  original ROM MD5:  0644da71f79d405a22934daa1474cefc
  patched ROM MD5:   90cd95c659beea6449ea71f37cbbfa2c

- The patched ROM is 8 MB (64 Mbit, ExHiROM): the new content does not
  fit in the original 4 MB. Use a patcher that can expand the file
  (Floating IPS, Lunar IPS, ROM Patcher JS, UniPatcher).
- If your ROM is 4,194,816 bytes (512-byte header, common in .smc
  files), remove the header first (ROM Patcher JS can do it).
- No MSU-1 needed. Tested in Snes9x and bsnes. Runs on emulators and
  flashcarts that support 64 Mbit ExHiROM (e.g. FXPak / SD2SNES).
  Flashcarts limited to 32 Mbit will not run it.


LATEST CHANGES (betas 57-99)
----------------------------
- Fixed: Shang Tsung had no second outfit (X on the select screen did
  nothing on him, nor on his opponent). Now both choose their colours. When
  Shang Tsung morphs into his opponent's fighter he always takes the other
  colours, so the two never look the same; other morphs keep the normal
  colours, as in the original game. (beta 99)
- Sheeva: the fatality where she punches the opponent into the floor now
  works on every stage. On The Temple and the Graveyard the opponent used
  to vanish, and on several other stages the buried body showed above the
  floor. Now only the head and shoulders stay out. (beta 98)
- Sheeva: her second fatality (hold HK, then Back, Forward, Forward and
  release, close) is now in the MOVELIST. (beta 98)
- Fixed: Sheeva thrown by Kitana, Jade, Khameleon and Mileena used
  leftovers from MK3 (she flew out of time, to the wrong side, or landed
  beside Kitana), and the knockdowns of the moves new in UMK3 (Mileena's
  roll, Reptile's force ball, Ermac's slam, Rain's lightning) left her
  lying flat in the air. She now uses her own frames. (beta 98)
- Chameleon: Down, Up (the teleport) can be used only once in a combo;
  when the combo ends it works normally again. (beta 98)
- Fixed: Noob Saibot's fatality (the slams until the opponent explodes)
  threw two bursts of bones with two skulls, one of them from a random
  place in memory, which could freeze the game on a real console. Now one
  burst comes out of the opponent. (beta 98)
- The TOURNAMENT MODE screen (hold L+R and press START in the main menu)
  was removed; L+R+START now works as a plain START. The 8 PLAYER
  TOURNAMENT KOMBAT mode is unchanged. (beta 98)
- Fixed: The Temple in TRAINING: after the menu the candle flames had
  stripes and the wall torches had no fire. A PAUSE on The Temple also
  spoiled two frames of the torches' fire. (beta 98)
- Cheats screen: the screen with the cheat codes that are on now comes up
  only before the first fight of a tower (and before each 2-player
  match), or again if the codes change, no longer before every round.
  Noob's Dorfen is behind it and Shao Kahn stands on the left: he laughs,
  points at you saying "You weak pathetic fool" and strikes his victory
  pose. THIS PLAYER ACTIVATED CHEATS stays at the top and the codes are
  centred under it. START does not skip it. (beta 97)
- Scorpion's Lair: a new sound when the stage fatality's uppercut sends
  the opponent through the ceiling and into the lava. (beta 97)
- Fixed: Sheeva's ending showed Kano's text. She now has her own ending,
  the text from MK3 for Super Nintendo. (beta 97)
- Fixed: Rain had no ending (the game went straight to the cast). His
  ending text, left unused in the original game, now comes up. (beta 97)
- PAUSE in every fight: START pauses (the fight is frozen and darkened,
  PAUSE in big gold letters, the music lower); START again goes back
  exactly where the fight was. SELECT opens BACK / MOVELIST / EXIT
  (Up / Down, START or A): BACK returns to PAUSE, EXIT gives up the fight
  and goes to the main menu (the tower starts again from CHOOSE YOUR
  DESTINY). In a 1-player fight START on the other controller still
  brings in a challenger. ENABLE PAUSE is no longer in the cheat list.
  (beta 96)
- MOVELIST: the special moves and finishers (fatalities, friendship,
  babality, stage fatality, brutality) of your fighter, with the Super
  Nintendo buttons of your own controller setup and the arrows for the
  side you are facing. Left / Right (or L / R) change pages; B, SELECT or
  START close it. It is in the PAUSE menu and in the TRAINING menu
  (SELECT). (beta 96)
- TRAINING: new option FATALITY TIME, NORMAL / INFINITE (with INFINITE
  the FINISH HIM time never runs out). (beta 96)
- Fixed: Motaro x Motaro (player Motaro against the CPU's in the tower).
  A tail fireball went back and forth between the two (Motaro throws
  projectiles back) and the next one could take over player 1's own
  Motaro: he was drawn all over the stage, a fireball flew around and the
  game hung at the end of the round. Now Motaro throws back only a
  projectile nobody has thrown back yet: in the mirror match the fireball
  comes back once and hits whoever threw it. (beta 96)
- Fixed: Rain's fatality (Down, Down, Back, Fwd + HK) never showed the
  FATALITY text. (beta 96)
- TRAINING: no VS screen any more (the fight starts right after the
  select screen). Changing DUMMY to or from CPU now happens in the same
  fight, without starting it again. With FINISH ON the other options are
  fixed (DUMMY STAND, BLOCK OFF, LIFE FINISH, RUN NORMAL) and shown in dark
  red; turning FINISH off gives your choices back. The TRAINING title is
  yellow. Fixed: while the menu was open, a fighter who was moving
  (running, thrown) kept moving and could even leave the stage; the fight
  is now fully frozen. The J in JUMP no longer looks like a T. (beta 95)
- TRAINING mode with its own menu: after the VS screen the fight starts
  frozen with the TRAINING menu on top - DUMMY (STAND / CROUCH / JUMP /
  CPU / PLAYER 2), BLOCK (OFF / ON / RANDOM), LIFE (INFINITE / REFILL),
  RUN (NORMAL / INFINITE) and FINISH (practise fatalities, babalities and
  mercy). In the fight START opens the menu: START goes back exactly
  where the fight was, B to the mode screen, X to the select screen.
  The cheat menus' codes have no effect in training. START + SELECT is
  no longer used. (beta 94)
- Mode select screen: B goes back to the main menu. (beta 94)
- 8 PLAYER TOURNAMENT: the bracket shows the names of Sheeva, Chameleon,
  Motaro, Shao Kahn, Khameleon and Triborg (it drew garbage), and
  Khameleon / Triborg stay themselves when they win a match (they went up
  the bracket, and into the next match, as Jade / Smoke). (beta 93)
- New hidden stage: Noob's Dorfen, as in MK3 - The Balcony without its
  back wall and the two Motaro statues, in dark colours, with the Hidden
  Portal's music. It is the 18th Kombat Zone stage and always the stage
  of Shao Kahn's treasure 6. (beta 92)
- MK3's Noob Saibot: Kano in black. Shao Kahn's treasure 6 (the
  silhouette) is now a fight against him alone (Ermac moved to treasure 7,
  with Classic Sub-Zero and Human Smoke). Beat him and, until the game is
  switched off, SELECT on Kano at the select screen turns Kano all black,
  and again black and grey: he plays as Kano, but the life bar says NOOB,
  the announcer calls him Noob Saibot and the win text is NOOB SAIBOT WINS.
  X on Kano still switches his two normal colours. (beta 92)
- Mode select screen: new art by Repliroid do Futuro (darker stone). The
  red frame of the chosen window now blinks between red and a darker red,
  and the mode names stay white in the chosen window too. (beta 91)
- Fixed: after beating Shao Kahn in 1 player the game stopped on a red
  screen (betas 84-89), so Shao Kahn's Lost Treasures and the endings
  never came up. Classic Sub-Zero's friendship (beta 84) had overwritten
  a few bytes of the music data played after Kahn's death. The winner
  text, the treasures and the endings are back. (beta 90)
- New mode select screen, art by Repliroid do Futuro: four windows side
  by side, MORTAL KOMBAT | 4 PLAYER 2 ON 2 KOMBAT | 8 PLAYER TOURNAMENT
  KOMBAT | TRAINING. Left / Right move between the four (TRAINING is now
  the fourth window); L / R on the second window switch it to 6 PLAYER
  3 ON 3 KOMBAT and back. The chosen window gets a red frame and red
  text, and the screen shakes when a mode is picked, as before. (beta 89)
- Main menu: the small coins next to the options now show up in the
  right place when you enter or come back to a menu, with a fade-in, and
  follow Up / Down at once. (beta 89)
- The ice ball of Sub-Zero, Classic Sub-Zero and Chameleon no longer
  freezes crouching fighters. Its hit area clipped the heads of some of
  them when crouching (Classic Sub-Zero: Kano, Kabal, Shang Tsung,
  Kitana, Jade, Mileena, Khameleon; Sub-Zero: Shang Tsung). It is now a
  little higher; standing fighters are hit as before. (beta 88)
- Rain's FRIENDSHIP: he keeps his hand up only while the rain falls. As
  soon as the last drop reaches the floor he does his victory pose; the
  flowers stay. (beta 87)
- Classic Sub-Zero's head rip (Down, Down, Down, Fwd + HP, close): the
  black screen with SUBZERO WINS, FLAWLESS VICTORY and FATALITY no longer
  flickers. Sub-Zero no longer shows for a frame or two, and stage sprites
  (the fire torches and the moon of some stages) no longer show through.
  Checked on every stage. (beta 86)
- Rain gets the FRIENDSHIP from Mortal Kombat Trilogy (N64): Down, Fwd,
  Fwd, Fwd + LP (B), from a sweep's distance, at FINISH HIM, without
  blocking in the round. He raises his arm (his lightning move) and keeps
  it up; water drops fall on the opponent (splashing on the floor) and
  small flowers grow on the floor around it: sprouts, then open, then in
  full bloom. The rain stops little by little and the flowers stay.
  (beta 85)
- Classic Sub-Zero's fatality where the screen goes black (Down, Down,
  Down, Fwd + HP, close): after the head rip the screen stays black, but
  SUBZERO WINS, FLAWLESS VICTORY (when the fight was perfect) and FATALITY
  now show on it. (beta 85)
- Classic Sub-Zero gets the snowman-in-a-box FRIENDSHIP from Mortal
  Kombat Trilogy (N64): Down, Back, Back, Fwd + LK (A), from a sweep's
  distance, at FINISH HIM, without blocking in the round. He winds the
  ninjas' music box and a snowman head pops out on a blue neck; the
  opponent gets scared and runs away. (beta 84)
- Nightwolf's fatality (Up, Up, Back, Fwd + Block, close): the skeleton
  shows inside the light beam again, the beam reaches the top of the
  screen (behind the HUD) and thins out at the end, as in the original.
  Its frames with the skeleton were too big for the per-frame graphics
  limit the hack uses in fights and never got drawn. (beta 84)
- Noob Saibot gets the SHADOW SPIN fatality from Mortal Kombat Trilogy
  (N64): Back, Back, Fwd, Fwd + HK (X), from a sweep's distance, at
  FINISH HIM. He raises his hand and keeps it up; his shadow comes down
  over the (still dizzy) opponent to its waist, the opponent rises with
  it and spins as in Sindel's hair fatality, spraying blood and bones.
  (beta 83)
- Noob's fatality (Down, Down + Run, close): he teleports only once; when
  he lands holding the opponent he keeps hold and slams it on the floor
  again and again, bouncing high and moving forwards, until it blows up.
  It does not come out if the slams would take the opponent to the edge
  of the stage (in a corner). (beta 83)
- Classic Sub-Zero's Ice Spike: the opponent again lands with the spike
  nearer its waist. In beta 80 the spike went through the chest, but some
  fighters land on it in their lying-on-the-floor frame, and for them that
  spot looked wrong. (beta 82)
- Rain gets the DEADLY UPPERCUT fatality (from the MUGEN Rain): Fwd,
  Fwd, Down + HP (Y), close, at FINISH HIM. He crouches and shakes from
  side to side for a second and a half, then does the last uppercut of
  his brutality: the opponent blows up, with the explosion sound, the
  scream, the screen shaking and the pieces. (beta 81)
- Classic Sub-Zero gets the ICE SPIKE fatality from Mortal Kombat
  Trilogy (N64): Down, Fwd, Fwd, Fwd + HP (Y), close, at FINISH HIM. He
  uppercuts the opponent, throws his ice on the floor (his Down, Back +
  LK move), a big ice spike rises from the middle of the ice and the
  opponent falls on it lying on the back, run through the chest,
  screaming and spraying blood. The ice and the spike stay to the end.
  It does not come out with the opponent against the corner (there must
  be room for it to land on the spike): then it is a normal uppercut.
  (beta 80)
- Noob Saibot's fatality (Down, Down + Run, close) could never be done:
  the Deluxe had its command written wrong. It works now. (beta 80)
- Select screen: fixed the garbage on the bottom row of the "?" slot (an
  animated glitch) and the gray/white pieces on the P1 preview (e.g.
  Kitana), seen e.g. in the 6-player mode. When the last round of a
  match ended at FINISH HIM (a 2-player win, a continue in 1 player...),
  the game still thought a fight was on, and the next select screen gave
  the previews their fight shadows. The shadows' graphics went over the
  "?" slot and the P1 preview. The select screen now always starts with
  the fight over. (beta 79)
- Select screen: both cursors are 1 pixel higher. (beta 79)
- CHOOSE YOUR DESTINY: the GOD tower no longer shows up, now and then,
  as a row of 9 Endurance fights with no Motaro and no Shao Kahn (a
  Deluxe test row in one of the game's 6 tower sets). It is a normal GOD
  tower again, as in the original game (two Endurance fights, Motaro,
  Shao Kahn), with Noob Saibot in place of the original's second Liu
  Kang. (beta 79)
- Hidden Portal: the bridge's pillars now reach the bottom of the screen
  (there was an empty strip under them and the bridge looked like it was
  floating). (beta 79)
- New name: UMK3 - EXTENDED EDITION (it was UMK3 Arcade Edition). The
  CREDITS screen (OPTIONS) and the name emulators and flashcarts show
  (the ROM header, "UMK3-EXTENDED EDITION": it holds 21 characters) use
  it. The patch is now UMK3_extended_edition.ips. (beta 78)
- Shao Kahn's Lost Treasures: the demonstrations no longer break.
  After a few minutes of the last treasure (all the demonstrations), the
  background turned into a bright, shifted temple, the fighters came out
  in pieces and the top of the screen filled with garbage until the GAME
  OVER. Triborg's variables were in a piece of memory the game also uses
  when many processes run at once, and the demonstrations fill it: the
  two overwrote each other. They are in free memory now. (beta 77)
- Shao Kahn's Lost Treasures: the fatality music plays in every
  demonstration (it played only in the first one, then there was
  silence). (beta 77)
- Select screen: new background picture (a dark stone wall over a stone
  floor), and the grid's outer border is now drawn like the lines
  between the slots. (beta 76)
- Triborg's juggle: the jump kick now knocks the opponent away with the
  game's normal fall (like any hit in the air: a short rise, then the
  diagonal fall). The slower fall of beta 73 looked odd. The teleport
  still catches the opponent in the air. (beta 75)
- Triborg's juggle: the spear comes out only once in a string. If the
  spear opened it (spear, then HP, HP, Down + LP...), it no longer comes
  out again after the teleport; Back, Back + LP gives the normal punch
  until the string is over. (beta 75)
- Triborg: HP, HP, Down + LP in the corner now pushes him back and keeps
  him in the combo's last frame until the opponent comes down, as the
  game does (e.g. Sektor). He used to recover right away and could rush
  the cornered opponent. The juggle therefore goes on only from
  mid-screen. (beta 75)
- Heavy fights (e.g. Motaro vs Shao Kahn in the tower): fixed the
  flicker where the whole HUD (life bars, names) vanished for a frame.
  When a frame's work ran late, a few screen registers were written after
  the top of the next frame had started and turned the HUD layer off.
  They are written earlier now; a late frame only leaves 1-2 black lines
  at the very top. (beta 75)
- Triborg's juggle no longer uses the net: during the juggle Back, Back
  + LK gives the normal kick (Cyrax's own rule), and a net that catches
  an opponent who has already landed starts a new string (the combo
  after it is a first one again). After the teleport, the spear goes on
  with the juggle. The net works as before outside the juggle, and the
  net followed by the combo still opens a juggle. (beta 74)
- "YOU UNLOCKED TRIBORG" screen: the text is no longer part of the
  picture. The three lines are real sprites in the font of "SHAO KAHN
  IS NO MORE" and rise from the bottom one after the other, as on that
  screen. (beta 74)
- Triborg's juggle: after the jump kick the opponent now falls away on
  the diagonal (it used to go up again). The fall is a bit slower, so
  the teleport still catches it in the air. (beta 73)
- Shao Kahn's Lost Treasures: fixed the fatality demonstrations. The
  Deluxe had changed 5 of the game's 8 demo lists into pairs where both
  fighters did a finisher at once (friendship + babality, two
  fatalities, animalities), which broke the scenes. They are back to the
  original lists: one fighter does his fatality, the other stands.
  Treasure 9 shows everything (fatalities 1 and 2, then friendships and
  babalities two at a time, as in the original game). (beta 73)
- Nightwolf's friendship: the MK2 arcade cabinet that falls next to him
  no longer flashes through the ninja colors (Chameleon's color cycle
  was catching its palette). (beta 73)
- Shao Kahn's Lost Treasures: after you beat Shao Kahn in 1 player, the
  treasure screen comes up, as in the arcade (the SNES game only had it
  in the 8-player tournament), with the menu music. Treasure 0 goes on
  to your ending; treasures 6 and 7 are the original Endurance fights
  (Noob Saibot + Ermac, Classic Sub-Zero + Human Smoke) on normal
  stages; treasure 8 is a fight against TRIBORG. (beta 72)
- New hidden fighter: TRIBORG, the three cyborgs in one (Cyrax, Sektor
  and Smoke), with their colors cycling. Beat him in treasure 8 to
  unlock him (a "YOU UNLOCKED TRIBORG" screen shows up), then press
  SELECT on the "?" slot of the select screen. The game has no save: he
  stays unlocked until you turn it off or reset. (beta 72)
    Cyrax's net: Back, Back + LK
    Cyrax's bombs: hold LK, Fwd, Fwd + HK (far) / Back, Back + HK (close)
    Sektor's missile: Fwd, Fwd + LP
    Sektor's homing missile: Fwd, Down, Back + HP
    Smoke's spear: Back, Back + LP
    Smoke's teleport punch: Fwd, Fwd + LK (also in the air)
    Smoke's air throw (Block in the air) and invisibility (Up, Up + Run)
    Combos: HP, HP, Down + LP (launcher) / HP, HP, HK, HK /
      HP, HP, LK, HK, LP
    Juggle: after HP, HP, Down + LP, jump in with a kick, teleport in
      the air (it knocks the opponent up again), land and throw the
      spear, do the combo again, then only normal hits and the air
      throw work until the opponent lands (the net: see beta 74)
    Fatalities: Cyrax Down, Down, Up, Down + HP; Sektor Fwd, Fwd, Fwd,
      Back + Block (far); Smoke Up, Up, Fwd, Down (hold Block, far)
    Smoke's brutality: Y, A, A, X, L, L, B, B, Y, L, L (HP, LK, LK, HK,
      BL, BL, LP, LP, HP, BL, BL)
  He has his own select and tower portraits, VS art, life bar name,
  "TRIBORG WINS", announcer voice, Smoke's victory pose, biography
  ("???" until he is unlocked) and ending, and no smoke cloud around
  him. He also works in the team modes. (beta 72)
- Player Motaro: new tail fireball (it comes out of the tip of his tail)
  with Down, Back + LK, and the screen shakes when he lands from a jump.
  (beta 72)
- Motaro's grab (CPU and player) no longer does damage when it catches;
  only the punch hurts, also when the opponent is blocking. (beta 72)
- Noob Saibot's teleport throw on Sheeva: she no longer ends up far from
  him in Sonya's pose; she is held like everyone else. (beta 72)
- Khameleon: after a Mercy the announcer no longer says "Jade". (beta 72)
- The game's version is shown on the OPTIONS screen, small, in the
  bottom right corner on the CREDITS line (VER.BETA71). (beta 71)
- Tower and 2-player stages are now picked at random from all 17 (each
  one once before any repeats, never the same twice in a row). The
  tower used to go through the same order every time, MK3 stages
  first, and the first fight after power-on was always on the Rooftop.
  The CPU Motaro and Shao Kahn keep their own stages, and KOMBAT ZONE
  still picks the stage. (beta 71)
- Endurance fights have random opponents (no repeats, never your own
  fighter). They used to be the same pairs (Kitana then Sheeva, Jax
  then Nightwolf). (beta 71)
- Fixed a tower freeze: sometimes a stage (e.g. Jade's Desert) showed
  up with no fighters, only the music. Some of the hack's variables
  were in the memory the game uses for its processes, and with many of
  them at once (Sheeva, Scorpion's Lair, Hidden Portal) the game got
  lost. (beta 71)
- The Pit 3: during the stage fatality, as the camera goes down, the
  names and life bars no longer vanish or break. (beta 71)
- Motaro fights (worse with Chameleon): fixed the short picture
  glitches (HUD and floor drawn a few lines off for one frame). In the
  heaviest frames the end-of-frame work ran out of time; the scanline
  effects (HUD, floor) now always start in place. (beta 71)
- Air throws on Liu Kang (Human Smoke, Scorpion): he no longer pops up
  behind the attacker when he lands. (beta 71)
- Khameleon's brutality now uses Mileena's commands: Y, B, B, Y, L, X,
  A, X, L, Y, B (HP, LP, LP, HP, BL, HK, LK, HK, BL, HP, LP). Jade keeps
  hers. (beta 71)
- When Shao Kahn wins a round the announcer says "I Win". The clip was
  already there, but it was asked for right away and the blood dripping
  on the floor took its voice; it now waits for the loser's scream to
  end. (beta 71)
- Removed every leftover of the Deluxe's animality (the game has no
  animality commands): the CPU's path to it, its table, its sounds and
  the "Animality" call. More free space in the ROM. (beta 71)
- CPU Motaro: his grab no longer pulls the opponent in from far away at
  once; he reaches out first (time to get away), only catches someone
  in reach and on the ground, and does not try from too far. Grabbed by
  the player's Motaro, he no longer hangs in the air after the punch. At
  the end of a combo he rears back and slides away much further, then
  waits a moment before attacking. (beta 70)
- Motaro (CPU and player) takes the heavy hit sound on the punch of the
  grab, on uppercuts and on the last hit of a combo. (beta 70)
- Fixed: pressing HP over and over made Khameleon throw Mileena's sai
  by accident. The sai now comes out only the proper way (hold HP, let
  go); mashing HP gives the punches and the combo. (beta 69)
- Khameleon has her own ending (one screen, her story over Jade's
  picture with Khameleon's colors cycling); it used to be Jade's.
  (beta 68)
- The CPU Khameleon now uses her own moves: Kitana's fan, Mileena's sai
  and Jade's boomerangs, picked at random (the game's AI picked her
  moves as Jade's). (beta 67)
- CHOOSE YOUR DESTINY: the 4th tower shows GOD again (beta 66 showed
  "KHAMELEON W..." there). (beta 67)
- New fighter: KHAMELEON (the Nintendo 64 Mortal Kombat Trilogy ninja),
  in Human Smoke's old slot. She cycles through Kitana's, Jade's and
  Mileena's colors and uses moves from all three (beta 66):
    Kitana's fan: Fwd, Fwd + HP + LP
    Jade's boomerangs: Back, Fwd + HP (high) / LP (straight) / LK (low);
      Back, Back, Fwd + LP (returning)
    Mileena's sai: hold HP, let go
    Combo: HP, HP, LP, LP, HK, HK, Down, Fwd + LK (7 hits, launcher)
    Mileena's throw
    Fatalities (close): Kitana's kiss (Run, Run, Block, Block + LK),
      Mileena's man-eater (Down, Fwd, Down, Fwd + LP), Jade's staff
      (Up, Up, Down, Fwd + HP)
    Stage fatality: Down, Down, Down + LP (close)
    Jade's friendship (Back, Down, Back, Back + HK) and babality
      (Down, Down, Fwd, Down + HK)
  She has her own select and tower portraits, VS art, life bar name,
  "KHAMELEON WINS", announcer voice and biography, and works in the
  tower, team modes and tournament.
- Human Smoke is now on Smoke's slot: press SELECT on Smoke to swap the
  portrait (with a fade) to Human Smoke and back. Random select never
  picks Human Smoke. (beta 66)
- The X button on the select screen picks the fighter's color (each
  fighter has two outfits; the second one used to show up only on P2 in
  a mirror match). In a mirror match with the same color, P2 (or the
  CPU) gets the other one. X no longer picks the fighter. Not for
  Chameleon and Khameleon (they cycle colors) or one-color fighters.
  Ermac and Noob got their second color back (darker red Ermac,
  all-black Noob, as in UMK3). (beta 66)
- Hidden Portal: no fighters running across the bridge and no Shao Kahn
  laugh before the fight. (beta 66)
- Stage fatalities: Chameleon's is now Fwd, Down + HP (Y), close.
  Mileena's (Down, Down, Down + LP) had to be done in 0.4 s, now 0.7 s.
  Soul Chamber no longer has one (the opponent got up again); they are on
  Scorpion's Lair, Bell Tower, The Pit 3 and The Subway. The Subway
  train passes 3x faster. (beta 66)
- Fixed the life bar glitch seen on some emulators and flash carts (a
  colored block over a letter of the name, a broken run meter): the HUD
  no longer changes a palette color mid-screen. (beta 65)
- BIOGRAPHIES is now an item of the SECRET STUFF screen, under SOUND
  TEST, in the big font (it was inside KOOLER STUFF). (beta 64)
- Ermac's fatality 2 (head punch: Run, Block, Run, Run, HK, close) can
  now be performed. On the original SNES cart a stray byte in Ermac's
  move list made the game read that entry one byte off. (beta 63)
- Motaro and Shao Kahn picked by a player can now fight on any stage
  (the normal order or the KOMBAT ZONE pick). CPU bosses in the tower
  still fight on their own stages. (beta 62)
- Playable Motaro: landing from a jump has a sound again (the same thud
  the CPU Motaro uses). (beta 61)
- Fixed a crash on Liu Kang's fatality (Fwd, Fwd, Down, Down, LK): a
  Chameleon table entry was written 2 bytes too far, over the start of
  that fatality's code. (beta 60)
- Fixed the graphics glitch in fights with Motaro and/or Shao Kahn (e.g.
  Motaro vs Shao Kahn): pink dots on the floor and background, wrong
  colors on the fighters. In the heaviest frames the end-of-frame work ran
  out of time, and the scanline effects were turned on without being
  reset, writing random colors into the palettes. They are now reset
  when that happens, and the sprite graphics sent per frame in a fight
  are capped a bit lower so it almost never happens. (beta 59)
- Bell Tower: fixed occasional frames where the whole screen was garbled
  (e.g. Chameleon vs Jax doing combos): the rope drawing code is about
  4x faster now. (beta 59)
- Liu Kang: after his launcher combo (HP, HP, Back+LP), every later hit
  did only 1/4 of the damage until the end of the round. Fixed. (beta 58)
- The Bridge: the gap under the floor is filled like on the other stages.
  Jump-in HP + combo now connects on Kitana, Jade and Mileena like on
  everyone else. (beta 57)


HIGHLIGHTS
----------
- Arcade-style select screen (7/7/5/5/5, "SELECT YOUR FIGHTER") with
  everyone unlocked: Sheeva, Chameleon, Khameleon, Motaro and Shao
  Kahn, each with a slot and portrait (Human Smoke on Smoke's slot).
  "?" slot = random select.
- Chameleon: cycles through every ninja's colors, one special move from
  each ninja, his own name, announcer voice, brutality and green blood.
- Khameleon: cycles through Kitana's, Jade's and Mileena's colors, with
  moves, combo and one fatality from each of them.
- Triborg (hidden): Cyrax, Sektor and Smoke in one, with moves, combos,
  a juggle and one fatality from each of them. Unlock him by beating him
  in Shao Kahn's Lost Treasures.
- Shao Kahn's Lost Treasures after beating Shao Kahn in 1 player.
- X on the select screen picks the fighter's color; SELECT on Smoke
  swaps to Human Smoke.
- Motaro and Shao Kahn: big VS-screen art and biographies; Motaro can't
  be launched or juggled.
- Arcade intro story (11 screens), redesigned main menu and mode select,
  CHOOSE YOUR DESTINY tower with the GOD tower.
- Fighter names inside the life bars, as in the arcade.
- Air combos for Kitana, Jade and Mileena.
- Random stage order in the tower and 2-player fights; random Endurance
  opponents.
- KOMBAT ZONE stage select (L / R on the select screen, cheat menu).
- OPTIONS > CREDITS screen.
- Many sound, announcer and graphics fixes; less slowdown in the Shao
  Kahn and Motaro fights.


TRAINING MODE
-------------
On the mode select screen TRAINING is the fourth window (press Right).
- Pick your fighter, then the opponent (controller 1 can pick both;
  controller 2 can pick the opponent).
- KOMBAT ZONE is on: L / R choose the stage before you pick.
- The fight starts frozen, with the TRAINING menu:
    DUMMY   STAND / CROUCH / JUMP / CPU / PLAYER 2 (controller 2 plays
            the opponent)
    BLOCK   OFF / ON / RANDOM
    LIFE    INFINITE / REFILL (hits take health but never the last
            point; the bar fills up again a moment later)
    RUN     NORMAL / INFINITE
    FINISH  OFF / ON (every round is the deciding one and the opponent
            has 1 point of health: one hit and it's FINISH HIM / HER.
            Fatalities, babalities and mercy work; after the finisher a
            new round starts with the same fighters. While FINISH is ON
            the other options are fixed: DUMMY STAND, BLOCK OFF, LIFE
            FINISH, RUN NORMAL; turning it off gives your choices back)
    FATALITY TIME  NORMAL / INFINITE (the FINISH HIM time)
  Up / Down choose, Left / Right change, START fights. The choices stay
  for the next training.
- In the fight START (either controller) opens the menu, with the fight
  frozen: START goes back exactly where it was, B to the mode select
  screen, X to the select screen (other fighters), SELECT shows player
  1's MOVELIST.
- Changes take effect in the same fight, CPU included (the opponent
  switches at its next neutral moment).
- The clock stops. The cheat menus' codes have no effect in training.
  While the menu is open the stage is hidden.


CREDITS
-------
UMK3 Deluxe content is used with permission from its author, Lucas
Dext5r.

- UMK3 Deluxe: Lucas Dext5r (2022)
- Original MSU-1 patch: Kurrono, Relikk, Conn
- Genesis "UMK3 Arcade" hack (reference): Nemesis_C
- This patch: Repliroid do Futuro (Gabriel Calmon)
